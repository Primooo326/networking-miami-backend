export enum TypeMail {
  verification = "verification",
  invitation = "invitation",
  passwordReset = "passwordReset",
  changeEmail = "changeEmail",
}

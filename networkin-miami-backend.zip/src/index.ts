import app from './app';
const port = 4000;
app.listen(port);
console.info('app listen in port', port);

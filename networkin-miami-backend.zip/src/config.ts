export default {
	SECRETKEY: 'pojasjid@#aoihs#447%78as_66',
};
